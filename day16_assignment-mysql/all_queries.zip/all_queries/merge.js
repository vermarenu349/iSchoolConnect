let mysql = require("mysql");

//----------------------------------------------

let conn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ischooldb"
})

conn.connect(function(err){
    if(err){console.log("ERROR: ",err);}
    else{
     let sql = "MERGE participants AS Target USING updated_participants AS Source ON Source.id = Target.id WHEN NOT MATCHED BY Target THEN INSERT(name,email) VALUES(Source.id,Source.name,Source.email) WHEN MATCHED THEN UPDATE SET Target.name = Source.name, Target.email = Source.email WHEN NOT MATCHED BY Source THEN DELETE; "
     conn.query(sql,function(err,res){
        if(err){console.log(err)}
        else{
            console.log("Response",res);
        }
    });
    }
})