let mysql = require("mysql");

//----------------------------------------------

let conn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ischooldb"
})

conn.connect(function(error){
    if(error){console.log(error);}
    else{
        /*let sql ="CREATE VIEW MarksView AS SELECT participants.name, participants.email, score.marks FROM participants, score WHERE participants.id = score.id;  "
        conn.query(sql,function(err,res){
            if(err){console.log(err);}
            else{
                console.log(res +"view created");
            }
        });*/
        let sql = "SELECT * FROM MarksView;"
        conn.query(sql,function(err,res){
            if(err){console.log(err);}
            else{
                console.log(res);
            }
        });
    }
})