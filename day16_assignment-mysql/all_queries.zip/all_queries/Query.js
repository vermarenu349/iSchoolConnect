let mysql = require("mysql");

//----------------------------------------------

let conn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ischooldb"
})

conn.connect(function(err){
    if(err){console.log("Error: ",err);}
    else{
        let sql = "SELECT * from participants WHERE id > 5";
        conn.query(sql,function(error,res){
            if(error){console.log("Error: ",error);}
            else{
                console.log(res);

            }
        });

        let sql2 = "SELECT * from participants WHERE id < 5";
        conn.query(sql2,function(error,res){
            if(error){console.log("Error: ",error);}
            else{
                console.log(res);

            }

        });

        let sql3 = "SELECT * from participants GROUP BY id HAVING mod(id,2) = 1";
        conn.query(sql3,function(error,res){
            if(error){
                console.log("Error: ",error);
            }
            else{
                console.log(res);

            }

        });

    }  
})