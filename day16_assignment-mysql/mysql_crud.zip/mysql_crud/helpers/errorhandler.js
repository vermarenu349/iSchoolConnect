let errorHandler = function(error){  console.log("Error :", error) };

module.exports = errorHandler;