import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { FirstComp } from './first.components';
import { FooterComp } from './footer.component';
import { HeaderComp } from './header.component';
import { MainComp } from './main.component';
import { ProductComp } from './product.component';

/*@NgModule({
  declarations: [
    AppComponent, FirstComp
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }*/

@NgModule({
  declarations: [
    AppComponent, HeaderComp,ProductComp,MainComp,FooterComp
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

