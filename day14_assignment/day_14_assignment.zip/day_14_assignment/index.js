const express = require("express");
const app = express();
const fs = require("fs");
const heroes = require("./data/heroes.json");

app.use(express.urlencoded({extended : true}));

let rawdata = fs.readFileSync("./data/heroes.json");
let hero = JSON.parse(rawdata);
app.get("/",function(req,res){

    res.render("home.jade",{
        registeruser: true,
        heros: hero
    });
})

app.post("/",function(req,res){
    hero.push(req.body.newhero);
    var json = JSON.stringify(hero,null,2);
    fs.writeFileSync("./data/heroes.json",json,"utf-8");
    res.redirect("/");
})

app.listen(8040,"localhost", function(error){
    if(error){
        console.log("Error",error);
    }
    else{
        console.log("server is now live on localhost:8040");
    }
});