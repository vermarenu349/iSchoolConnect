addEventListener("load",init);
        var can,ctx,boxX= -100,boxY = 0,boxD=100;
        function init(){
            can = document.getElementById("can");
            ctx = can.getContext("2d");
            setInterval(animation,100);
        };
        function animation(){
            /*for random places*/
            boxX = Math.round(Math.random() * 200);
            boxY = Math.round(Math.random() * 200);
            /*for changing box sizes*/
            boxD = Math.round(Math.random() * 100);
            /* for random colors of rectangle*/
            var red = Math.round(Math.random() * 255);
            var green = Math.round(Math.random() * 255);
            var blue = Math.round(Math.random() * 255);
            var alpha = Math.random();
            ctx.fillStyle = "rgba("+red+","+green+","+blue+","+alpha+")";
            ctx.fillRect(boxX,boxY,boxD,boxD);
        };