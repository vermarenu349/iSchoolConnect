const express = require("express");
const app = express();
const { default: mongoose } = require("mongoose");
const mangoose = require("mongoose");

app.use(express.static(__dirname+"/public"));

app.use(express.json());
let errorHandler = function(error){console.log("Error: ",error)}
const url = "mongodb+srv://admin:Everain007@mycluster.kaosm.mongodb.net/Project1?retryWrites=true&w=majority";
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Categories = mongoose.model("Categories",new Schema({
    id: ObjectId,
    category: String,
}))
let Questions = mongoose.model("Questions",new Schema({
    id:ObjectId,
    questioncat:String,
    questionCode:String,
    questionPhrase:String,
    answerNo:Number,
    answerscore1:String,
    answerscore2:String,
    answerscore3:String,
    answerscore4:String,
    answerchoice1:String,
    answerchoice2:String,
    answerchoice3:String,
    answerchoice4:String,

}))
mongoose.connect(url)
.then(()=>console.log("DB connected"))
.catch(error => errorHandler(error));

app.get("/data",function(req,res){
    console.log("get function for data recieved");
    Categories.find(function(error,categories){
        if(error){errorHandler(error)}
        else{ res.json(categories)}
    })
});


app.get("/getQuestions",function(req,res){
    Questions.find(function(err, que){
        if(err){errorHandler(err)}
        else{
            res.json(que);
            console.log(que);
        }
    })
})

app.post("/add",function(req,res){
//console.log("add user post request recieved", req.body);
       let categories = new Categories(req.body);
        categories.save()
        .then(function(){
            res.json({'message':'Category added'})
        })
        .catch(function(err){
            errorHandler(err);
        })
    })

app.post("/save",function(req,res){
    let question = new Questions(req.body);
    question.save().then(function(){
        res.json({'message':'Question added'})
    })
    .catch(function(err){
        errorHandler(err);
    })

})



app.listen(8080,"localhost", function(error){
    if(error){
        console.log("Error",error);
    }
    else{
        console.log("server is now live on localhost:8080");
    }
});




/*const fs = require("fs");
app.use(express.urlencoded({extended : true}));*/

/*let rawdata = fs.readFileSync("./data/category.json");
let Category = JSON.parse(rawdata);*/

/*
app.get("/",function(req,res){
    
    res.render("home.html",{
       // cat:Category.Categories,
        //len:Category.Categories.length
       
    });
    
})

app.post("/",function(req,res){
    let myobj ={
        category:req.body.category,
        anstype:req.body.anstype
    }
    Category["Categories"].push(myobj);
    var json = JSON.stringify(Category,null,2);
    fs.writeFileSync("./data/category.json",json,"utf-8");
    res.redirect("/");
})
*/